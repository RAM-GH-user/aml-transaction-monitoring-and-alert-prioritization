# AML Transaction Monitoring Optimization (Python + SQL)

**Rule-based anti-money-laundering monitoring, then optimization: 10 detection rules, alert consolidation, customer risk scoring, and a segmentation + logistic regression model that replaces a broad rule cutoff with a risk score.**

| Result (synthetic data) | Value |
|---|---|
| Transactions monitored | 265,165 across 948 customers (Jan–Oct 2026) |
| Suspicious customers caught by rules | 87 of 88 |
| Alerts after segmenting one rule | 419 (down from 1,040) |
| Logit model on the large-cash rule | 28% fewer alerts at 96% recall, out-of-time test |

> The data is synthetic because real bank data is confidential. Real alert queues are noisier; the measure-and-tune method is the point of the project.

**Author:** Ramanath Reddy Alamuru · [LinkedIn](https://www.linkedin.com/in/ramanathreddya)

---

## Repository structure

```
aml-transaction-monitoring/
├── sql/
│   └── 02_aml_rules.sql          # the 10 detection rules (SQLite; portable SQL)
├── python/
│   ├── data_generation.py        # synthetic customers, transactions, planted typologies
│   ├── data_profiling.py         # data quality, mix, trends, alert volume and conversion
│   ├── rule_evaluation.py        # runs the SQL rules, builds alerts and risk scores, measures each rule
│   └── alert_scoring.py          # segmentation + logistic regression on the large-cash rule
├── sas/                          # SAS versions, added as they are implemented
├── reports/
│   └── AML_Transaction_Monitoring_Project_Report.pdf
├── data/                         # generated inputs (large files are git-ignored)
├── outputs/                      # generated results (CSV)
├── requirements.txt
└── .gitignore
```

## How to run

From the repository root:

```bash
pip install -r requirements.txt
python python/data_generation.py   # 1. create the synthetic data in data/
python python/data_profiling.py    # 2. profile the data
python python/rule_evaluation.py   # 3. run the 10 rules, score customers, measure rules
python python/data_profiling.py    # 4. re-run to profile alert volume and conversion
python python/alert_scoring.py     # 5. segmentation + logit model on the large-cash rule
```

The whole pipeline runs in under a minute. `data/aml.db` is a SQLite database you can open in DB Browser for SQLite to run any rule by hand.

## Approach

1. **Know the typologies:** map each red flag to a named laundering risk.
2. **Profile the data:** quality checks, volumes, mix, trends, activity near thresholds.
3. **Write rules in SQL:** 10 rules with documented thresholds and weights.
4. **Alert and score:** one alert per customer, rule and period; customers scored into HIGH, MEDIUM and LOW tiers.
5. **Measure each rule:** alerts, precision and detection per rule.
6. **Optimize:** segment customers, then replace broad cutoffs with a statistically grounded model, validated out of time.

## The 10 rules

| # | Rule | Logic (starting threshold) | SQL technique |
|---|------|----------------------------|---------------|
| R01 | Large cash | Cash ≥ $10,000 (CTR threshold) | `WHERE` + `GROUP BY` |
| R02 | Structuring | 3+ cash deposits of $8K–$9,999 within 7 days, total ≥ $10K | Rolling-window self-join |
| R03 | High-risk geography | Wire ≥ $1K to/from a high-risk country (sample: IR, KP, MM) | `IN` list / reference table |
| R04 | Sudden wealth | Monthly inflow > 5× declared income and ≥ $25K | Join to KYC + `HAVING` |
| R05 | Velocity | 15+ transactions in one day | `GROUP BY` day + `HAVING` |
| R06 | International wires | 3+ outbound international wires in 30 days, total ≥ $25K | Rolling 30-day self-join |
| R07 | Rapid movement | In ≥ $10K, then ≥ 80% out within 3 days (individuals only) | Self-join, in vs out |
| R08 | Round amounts | 5+ exact $1,000-multiple transactions in a month | Modulo |
| R09 | Dormant reactivation | Transaction ≥ $5K after 180+ days of no activity | Window function `LAG()` |
| R10 | Funnel / mule account | Individual receives from 10+ different senders in 30 days | `COUNT(DISTINCT)` in window |

## Results

- **87 of 88** planted bad actors caught by at least one rule; every rule caught its target typology except R08 (7 of 8).
- **Segmentation (R07):** the first version of rapid movement flagged 47 legitimate businesses. Limiting it to individuals removed all 47 and cut total alerts from 1,040 to 419.
- **Calendar vs rolling windows (R08):** the one miss came from a monthly window splitting a customer's activity. A rolling 30-day window fixes it.
- **R01 large cash** is high-volume and low-conversion, so it gets the model treatment below.

## Optimization: segmentation + logistic regression (R01)

`python/alert_scoring.py`:

1. **Segment** the alerted population and measure conversion: repeat large cash at a business converts at 98%; first-time large cash at about 17%.
2. **Logit model** on six features from the 90 days before each alert (no look-ahead): prior large-cash count, amount, business flag, tenure, cash share of inflows, cash-to-income.
3. **Cutoff set on Jan–Jul** for 95% recall, then **tested on Aug–Oct**: 28% fewer alerts, 96% of productive alerts kept, conversion up from 34% to 46%, ROC-AUC 0.97.
4. **Odds ratios** (`outputs/logit_odds_ratios.csv`) document every driver for model validation. Cash-to-income has an unexpected negative sign because it overlaps with amount and business type; it is flagged for a multicollinearity check before sign-off.

## Outputs

| File | Contents |
|------|----------|
| `outputs/alerts.csv` | Every alert raised |
| `outputs/customer_risk_scores.csv` | One row per flagged customer: score, tier, rules hit |
| `outputs/rule_performance.csv` | Precision and detection per rule |
| `outputs/profile_*.csv` | Data quality, transaction mix, monthly trend, alert conversion |
| `outputs/logit_*.csv` | Segment conversion, model results, odds ratios |

## Next steps

- SAS versions of the pipeline in `sas/` (`PROC SQL`, DATA step with `LAG`, `PROC LOGISTIC`, `PROC COMPARE`)
- Rolling-window fix for R08; new rules for one-to-many and cash-in/wire-out
- Real-time version of the time-critical rules (rapid movement, velocity) on a transaction stream
- Power BI dashboard on the `outputs/` files

## Sources

- [GAO-25-106500: Currency Transaction Reports](https://www.gao.gov/products/GAO-25-106500)
- [FFIEC BSA/AML Examination Manual: Suspicious Activity Reporting](https://bsaaml.ffiec.gov/manual/AssessingComplianceWithBSARegulatoryRequirements/04)
- [FATF High-Risk Jurisdictions subject to a Call for Action](https://www.fatf-gafi.org/en/publications/High-risk-and-other-monitored-jurisdictions/call-for-action-october-2026.html)
- [Federal Reserve SR 26-2: Revised Guidance on Model Risk Management](https://www.federalreserve.gov/supervisionreg/srletters/sr2602.htm)

## Use of AI

I used an AI assistant (Claude, by Anthropic) to brainstorm rule ideas, draft code and synthetic data, and help write the documentation. I chose the rules and thresholds, ran and checked every script, and made the tuning decisions.
